package com.example.demoapp;

import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.navigation.Navigation;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.message);
        TextView textView2 = findViewById(R.id.message2);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(Navigation.createNavigateOnClickListener(R.id.imFragment, null));
        textView.setOnClickListener(Navigation.createNavigateOnClickListener(R.id.editFragment,null));


        int amount = ConfirmationFragmentArgs.fromBundle(getArguments()).getAmount();
        textView2.setText(amount + "");

    }



}
