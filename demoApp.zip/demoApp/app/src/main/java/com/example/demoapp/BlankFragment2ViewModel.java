package com.example.demoapp;

import android.arch.lifecycle.ViewModel;

public class BlankFragment2ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
